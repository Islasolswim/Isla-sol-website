# Isla Sol — Editorial Website Starter

An original, responsive luxury swimwear landing page with an editorial fashion aesthetic. No Cult Gaia logos, assets, or proprietary code are included. The visuals are original CSS concept artwork; replace them with licensed brand photography before launching.

## Upload to GitHub
1. Download and unzip the archive.
2. Create a new GitHub repository (e.g. `isla-sol-site`).
3. Choose **Add file → Upload files** and upload the **contents** of the unzipped folder (`index.html`, `styles.css`, `script.js`, `assets/`, etc.). Commit changes. Alternatively, push the folder with Git.
4. For a preview: Repository **Settings → Pages → Deploy from a branch → main / (root)**. Your site will be available at the GitHub Pages URL after deployment.

## Important before launch
- Replace CSS concept artwork with your own product and campaign images.
- Update Instagram URL and `hello@example.com` in `index.html`.
- The email form is a **demo only**; connect Klaviyo, Shopify Email, or your email platform before publishing.
- Product cards are previews, **not a functioning Shopify checkout**. To sell products, integrate Shopify Buy Buttons, Storefront API, or rebuild sections in a Shopify theme.
- The clean-water section intentionally says **intends to**; update only when your giving commitment and partner are confirmed.
- Google Fonts load from the internet. For custom brand fonts, self-host properly licensed font files and update `styles.css`.

## Files
- `index.html`: site sections and content
- `styles.css`: all styling and responsive layouts
- `script.js`: mobile menu and demo form
- `assets/`: reserved for your photography and logos

This is a static website suitable for GitHub Pages. Uploading the ZIP directly to GitHub does not unpack it; unzip first.
